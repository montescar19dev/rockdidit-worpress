//////////////////////////////////////////////////////////////////////
//																	//
// 	Don't translate your language here.								//
// 	We have dedicated translation app for translate Element Pack	//
// 	Please go to https://bdthemes.co/ep-translate/			 		//
// 	Register there and modify your language and download it. 		//
//																	//
//////////////////////////////////////////////////////////////////////

